#ifndef _SCIF2
#define _SCIF2

#include "integer.h"

void scif2_init (void);
int scif2_test (void);
void scif2_put (BYTE);
BYTE scif2_get (void);

#endif

