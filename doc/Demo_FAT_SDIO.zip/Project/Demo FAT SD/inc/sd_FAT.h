#include "ff.h"
#include "diskio.h"
#include "main.h"

FRESULT die(FRESULT res);
void sd_FAT(void);

